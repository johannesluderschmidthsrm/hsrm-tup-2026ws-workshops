// alle three.js Standardkomponenten importieren
import * as THREE from 'three';
// import für GLTF loader
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
// import für interaktive Orbitkamera
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';



// RENDERER
// wir brauchen immer einen Renderer
// Optionale Parameter nach Bedarf
const renderer = new THREE.WebGLRenderer(/*{ alpha: true, antialias: true }*/);
// Referenz auf das HTML Element, das Platzhalter für unsere 3d-Szene ist
const container = document.getElementById('3d-bereich');
// Rendertarget platzieren
container.appendChild(renderer.domElement);
// und die Größe anpassen
renderer.setSize(container.clientWidth, container.clientHeight);



// SZENE
// enthält alle 3d-Elemente, die wir erstellen oder importieren
const scene = new THREE.Scene();
// optional: Hintergrundfarbe
scene.background = new THREE.Color(0x8080ff);



// KAMERA
// Parameter: Blickwinkel (50 Standard), Seitenverhältnis (1 Standard)
// wird im Nullpunkt erzeugt und schaut in Richtung -z
const camera = new THREE.PerspectiveCamera(50, container.clientWidth / container.clientHeight);
// Nach Bedarf positionieren
camera.position.y = 3;
camera.position.z = 5;
// wir können auch rotieren (Rotation in Radian)
camera.rotation.x = -Math.PI/8;
// Optional: Interaktive Kamerasteuerung hinzufügen
// Änderungen werden nur sichtbar, wenn wir auch neu rendern (z.B. im animation loop oder event handler)
//const controls = new OrbitControls(camera, renderer.domElement);



// OBJEKTE
// Ein Würfel in (0,0,0)
const cubeGeometry = new THREE.BoxGeometry(2, 2, 2); // Parameter: Breite, Höhe, Tiefe
const cubeMaterial = new THREE.MeshStandardMaterial({ color: 0xff8000 });
const cube = new THREE.Mesh(cubeGeometry, cubeMaterial);
scene.add(cube);
// Eine Sphäre auf dem Würfel
const sphereGeometry = new THREE.SphereGeometry(1); // Parameter: Radius
const sphereMaterial = new THREE.MeshStandardMaterial({ color: 0x000000 });
const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
sphere.position.y = 2;
scene.add(sphere);
// Und ein Licht
const light = new THREE.PointLight(0xffffff, 100);
light.position.y = 5;
light.position.z = 5;
scene.add(light);



// GLTF LADEN
//let model; // noch <undefined>, referenziert nach dem Laden unsere Blender-Szene
//const loader = new GLTFLoader();
// Loader kann *.glb oder *.gltf laden. Für andere Formate gibt es analog ähnliche Loader
//loader.load('pfad/zur/datei.glb', function (gltf) {
  // Asynchron! Diese Funktion wird erst nach dem Laden ausgeführt!
  //model = gltf.scene; // model ist nicht mehr <undefined>
  // eventuell die ganze Blender-Szene noch etwas skalieren oder positionieren
  //model.scale.set(3, 3, 3);
  //model.position.y = -1;

  // oder optional mit spezifischen Elementen interagieren
  //const cube = model.getObjectByName('MyFavoriteCube');

  // Lichter aus Blender sind zu hell?
  //model.traverse( function(object) {
  //  if (object.isLight) {
  //    object.intensity /= 500;
  //  }
  //});

  // und schließlich kommt alles in unsere szene
  //scene.add(model);
//});



// TEXTUR LADEN
// Falls wir eine Texture brauchen: Dieser Loader ist Standardkomponente und kein extra Import aus addons
//const bgLoader = new THREE.TextureLoader();
//bgLoader.load('pfad/zur/textur.jpg', function (texture) {
  // diese Funktion ist auch wieder asynchron!
  // Falls texture außerhalb der Funktion benötigt wird, erst definieren und dann zuweisen wie bei model
  // Für jpg oder png müssen wir colorSpace anpassen. Standard ist linear und die Textur wird zu hell
  //texture.colorSpace = THREE.SRGBColorSpace;
  // ist es eine environment map? Das müssen wir three.js mitteilen
  //texture.mapping = THREE.EquirectangularReflectionMapping;

  // eventuell als environment map zuweisen
  //scene.environment = texture;

  // oder einfach als Hintergrund nutzen?
  //scene.background = texture;
//});



// ANIMATION
// Optional: AnimationLoop ist eine Funktion, die in jedem Frame aufgerufen wird
// hier können wir neu rendern und eventuell Animationen abspielen
renderer.setAnimationLoop(function() {
  // wird in jedem Frame update ausgeführt

  // vielleicht soll irgendwas rotieren
  cube.rotation.y -= 0.01;

  // material kann auch animiert werden
  sphere.material.color.g += 0.005;
  if (sphere.material.color.g > 1.0) {
    sphere.material.color.g = 0.0;
  }

  // nach Änderungen rendern nicht vergessen
  renderer.render(scene, camera);
});



// SONSTIGE EVENT HANDLER
// werden nur ausgeführt, wenn das entsprechende Ereignis passiert

// window resize (falls Responsive)
// Wenn unser render nie die Größe ändern soll ist dies optional
window.addEventListener('resize', function () {
  // wie oben: Größe für renderer und Seitenverhältnis für Kamera
  renderer.setSize(container.clientWidth, container.clientHeight);
  camera.aspect = container.clientWidth / container.clientHeight;
  // Wenn sich Eigenschaften der Kamera nach dem ersten Erstellen ändern müssen wir updateProjectionMatrix aufrufen
  camera.updateProjectionMatrix();
  // und neu rendern (falls wir keinen Animation Loop haben und eh ständig neu rendern)
  renderer.render(scene, camera);
});

// Wollen wir auf Tastatureingaben reagieren?
//document.addEventListener("keydown", onKeyDown);
//function onKeyDown(event) {
//  if (event.key === "1") {
//    ...
//  }
//};

// Oder wollen wir auf Buttons reagieren?
//const button = document.getElementById('buttonID');
//button.onclick = function() {
//  ...
//}

// weitere Handler nach Bedarf...